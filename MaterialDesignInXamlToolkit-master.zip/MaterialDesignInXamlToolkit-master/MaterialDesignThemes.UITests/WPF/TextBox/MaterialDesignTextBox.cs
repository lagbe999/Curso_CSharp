﻿using System;

namespace MaterialDesignThemes.UITests.WPF.TextBox
{
    public static class MaterialDesignTextBox
    {
        public static TimeSpan FocusedAimationTime { get; } = TimeSpan.FromSeconds(0.45);
    }
}
