﻿namespace MaterialDesignThemes.Wpf
{
    public enum Contrast
    {
        None,
        Low,
        Medium,
        High
    }
}