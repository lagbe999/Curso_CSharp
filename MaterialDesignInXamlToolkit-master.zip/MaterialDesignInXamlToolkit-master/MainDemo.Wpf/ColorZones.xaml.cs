﻿namespace MaterialDesignDemo
{
    public partial class ColorZones
    {
        public ColorZones() => InitializeComponent();
    }
}
