﻿using System.Windows.Controls;

namespace MaterialDesignDemo.Domain
{
    /// <summary>
    /// Interaction logic for SampleMessageDialog.xaml
    /// </summary>
    public partial class SampleMessageDialog : UserControl
    {
        public SampleMessageDialog()
        {
            InitializeComponent();
        }
    }
}
