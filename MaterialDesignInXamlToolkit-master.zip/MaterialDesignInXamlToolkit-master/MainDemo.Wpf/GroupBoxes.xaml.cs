﻿namespace MaterialDesignDemo
{
    public partial class GroupBoxes
    {
        public GroupBoxes() => InitializeComponent();
    }
}
