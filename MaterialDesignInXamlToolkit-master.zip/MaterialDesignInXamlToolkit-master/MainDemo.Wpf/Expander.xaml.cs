﻿namespace MaterialDesignDemo
{
    public partial class Expander
    {
        public Expander() => InitializeComponent();
    }
}
