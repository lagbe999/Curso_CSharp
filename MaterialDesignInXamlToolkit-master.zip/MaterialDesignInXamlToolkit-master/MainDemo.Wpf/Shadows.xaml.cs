﻿namespace MaterialDesignDemo
{
    public partial class Shadows
    {
        public Shadows() => InitializeComponent();
    }
}
