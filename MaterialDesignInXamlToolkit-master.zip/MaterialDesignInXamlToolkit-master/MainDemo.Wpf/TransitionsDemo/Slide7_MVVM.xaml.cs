﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide7_MVVM.xaml
    /// </summary>
    public partial class Slide7_MVVM : UserControl
    {
        public Slide7_MVVM()
        {
            InitializeComponent();
        }
    }
}
