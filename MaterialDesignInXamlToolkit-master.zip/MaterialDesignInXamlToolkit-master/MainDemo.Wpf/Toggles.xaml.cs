﻿namespace MaterialDesignDemo
{
    public partial class Toggles
    {
        public Toggles() => InitializeComponent();

    }
}
