﻿using System.Windows.Controls;

namespace MahMaterialDragablzMashUp
{
    /// <summary>
    /// Interaction logic for FlyoutContent.xaml
    /// </summary>
    public partial class FlyoutContent : UserControl
    {
        public FlyoutContent()
        {
            InitializeComponent();
        }
    }
}
