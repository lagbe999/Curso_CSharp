﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTestAssembly
{
	/// <summary>
	/// Represents all of the different things that can be dragged onto the design surface.
	/// </summary>
	public enum MyFooEnum
	{
		ButtonWidget,
		TextWidget
	}
}
