﻿namespace ICSharpCode.WpfDesign.Designer
{
    public enum StretchDirection
	{
        Width,
		Height,
    }
}
