# Projects and Assemblies

The following assemblies are being produced today: 
```
+---net472
|   |   PresentationBuildTasks.dll
|   |   System.Collections.Immutable.dll
|   |   System.Memory.dll
|   |   System.Numerics.Vectors.dll
|   |   System.Reflection.Metadata.dll
|   |   System.Reflection.MetadataLoadContext.dll
|   |   System.Runtime.CompilerServices.Unsafe.dll
|   |   
|   +---cs
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---de
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---es
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---fr
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---it
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---ja
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---ko
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---pl
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---pt-BR
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---ru
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---tr
|   |       PresentationBuildTasks.resources.dll
|   |       
|   +---zh-Hans
|   |       PresentationBuildTasks.resources.dll
|   |       
|   \---zh-Hant
|           PresentationBuildTasks.resources.dll
|           
\---netcoreapp2.1
    |   PresentationBuildTasks.dll
    |   System.Reflection.MetadataLoadContext.dll
    |   
    +---cs
    |       PresentationBuildTasks.resources.dll
    |       
    +---de
    |       PresentationBuildTasks.resources.dll
    |       
    +---es
    |       PresentationBuildTasks.resources.dll
    |       
    +---fr
    |       PresentationBuildTasks.resources.dll
    |       
    +---it
    |       PresentationBuildTasks.resources.dll
    |       
    +---ja
    |       PresentationBuildTasks.resources.dll
    |       
    +---ko
    |       PresentationBuildTasks.resources.dll
    |       
    +---pl
    |       PresentationBuildTasks.resources.dll
    |       
    +---pt-BR
    |       PresentationBuildTasks.resources.dll
    |       
    +---ru
    |       PresentationBuildTasks.resources.dll
    |       
    +---tr
    |       PresentationBuildTasks.resources.dll
    |       
    +---zh-Hans
    |       PresentationBuildTasks.resources.dll
    |       
    \---zh-Hant
            PresentationBuildTasks.resources.dll
\---net6.0
    |   DirectWriteForwarder.dll
    |   DirectWriteForwarder.pdb
    |   PresentationCore.dll
    |   PresentationCore.pdb
    |   PresentationFramework-SystemCore.dll
    |   PresentationFramework-SystemCore.pdb
    |   PresentationFramework-SystemData.dll
    |   PresentationFramework-SystemData.pdb
    |   PresentationFramework-SystemDrawing.dll
    |   PresentationFramework-SystemDrawing.pdb
    |   PresentationFramework-SystemXml.dll
    |   PresentationFramework-SystemXml.pdb
    |   PresentationFramework-SystemXmlLinq.dll
    |   PresentationFramework-SystemXmlLinq.pdb
    |   PresentationFramework.Aero.dll
    |   PresentationFramework.Aero.pdb
    |   PresentationFramework.Aero2.dll
    |   PresentationFramework.Aero2.pdb
    |   PresentationFramework.AeroLite.dll
    |   PresentationFramework.AeroLite.pdb
    |   PresentationFramework.Classic.dll
    |   PresentationFramework.Classic.pdb
    |   PresentationFramework.dll
    |   PresentationFramework.Luna.dll
    |   PresentationFramework.Luna.pdb
    |   PresentationFramework.pdb
    |   PresentationFramework.Royale.dll
    |   PresentationFramework.Royale.pdb
    |   PresentationUI.dll
    |   PresentationUI.pdb
    |   ReachFramework.dll
    |   ReachFramework.pdb
    |   System.Printing.dll
    |   System.Printing.pdb
    |   System.Windows.Controls.Ribbon.dll
    |   System.Windows.Controls.Ribbon.pdb
    |   System.Windows.Input.Manipulations.dll
    |   System.Windows.Input.Manipulations.pdb
    |   System.Windows.Presentation.dll
    |   System.Windows.Presentation.pdb
    |   System.Xaml.dll
    |   System.Xaml.pdb
    |   UIAutomationClient.dll
    |   UIAutomationClient.pdb
    |   UIAutomationClientSideProviders.dll
    |   UIAutomationClientSideProviders.pdb
    |   UIAutomationProvider.dll
    |   UIAutomationProvider.pdb
    |   UIAutomationTypes.dll
    |   UIAutomationTypes.pdb
    |   WindowsBase.dll
    |   WindowsBase.pdb
    |   WindowsFormsIntegration.dll
    |   WindowsFormsIntegration.pdb
    |   
    +---cs
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---de
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---es
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---fr
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---it
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---ja
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---ko
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---pl
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---pt-BR
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---ru
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---tr
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    +---zh-Hans
    |       PresentationCore.resources.dll
    |       PresentationFramework.resources.dll
    |       PresentationUI.resources.dll
    |       ReachFramework.resources.dll
    |       System.Printing.resources.dll
    |       System.Windows.Controls.Ribbon.resources.dll
    |       System.Windows.Input.Manipulations.resources.dll
    |       System.Xaml.resources.dll
    |       UIAutomationClient.resources.dll
    |       UIAutomationClientSideProviders.resources.dll
    |       UIAutomationProvider.resources.dll
    |       UIAutomationTypes.resources.dll
    |       WindowsBase.resources.dll
    |       WindowsFormsIntegration.resources.dll
    |       
    \---zh-Hant
            PresentationCore.resources.dll
            PresentationFramework.resources.dll
            PresentationUI.resources.dll
            ReachFramework.resources.dll
            System.Printing.resources.dll
            System.Windows.Controls.Ribbon.resources.dll
            System.Windows.Input.Manipulations.resources.dll
            System.Xaml.resources.dll
            UIAutomationClient.resources.dll
            UIAutomationClientSideProviders.resources.dll
            UIAutomationProvider.resources.dll
            UIAutomationTypes.resources.dll
            WindowsBase.resources.dll
            WindowsFormsIntegration.resources.dll
\---win-x86
    \---native
            D3DCompiler_47_cor3.dll
            PenImc_cor3.dll
            PenImc_cor3.pdb
            PresentationNative_cor3.dll
            PresentationNative_cor3.pdb
            vcruntime140d.dll
            wpfgfx_cor3.dll
            wpfgfx_cor3.pdb
\---win-x64
    \---native
            D3DCompiler_47_cor3.dll
            PenImc_cor3.dll
            PenImc_cor3.pdb
            PresentationNative_cor3.dll
            PresentationNative_cor3.pdb
            vcruntime140d.dll
            wpfgfx_cor3.dll
            wpfgfx_cor3.pdb			
```        

The following projects exist in the repo. Those corresponding to the assemblies listed above are currently building. 

```
cycle-breakers\PresentationFramework\PresentationFramework-PresentationUI-api-cycle.csproj
cycle-breakers\PresentationFramework\PresentationFramework-ReachFramework-impl-cycle.csproj
cycle-breakers\PresentationFramework\PresentationFramework-System.Printing-api-cycle.csproj
cycle-breakers\PresentationFramework\PresentationFramework-System.Printing-impl-cycle.csproj
cycle-breakers\PresentationUI\PresentationUI-PresentationFramework-impl-cycle.csproj
cycle-breakers\ReachFramework\ReachFramework-PresentationFramework-api-cycle.csproj
cycle-breakers\ReachFramework\ReachFramework-System.Printing-api-cycle.csproj
cycle-breakers\System.Printing\System.Printing-PresentationFramework-api-cycle.csproj

redist\D3DCompiler\D3DCompiler.vcxproj
redist\PresentationNative\PresentationNative.vcxproj
redist\VCRuntime\VCRuntime.vcxproj

src\DirectWriteForwarder\DirectWriteForwarder.vcxproj

src\Extensions\PresentationFramework-SystemCore\PresentationFramework-SystemCore.csproj
src\Extensions\PresentationFramework-SystemData\PresentationFramework-SystemData.csproj
src\Extensions\PresentationFramework-SystemDrawing\PresentationFramework-SystemDrawing.csproj
src\Extensions\PresentationFramework-SystemXml\PresentationFramework-SystemXml.csproj
src\Extensions\PresentationFramework-SystemXmlLinq\PresentationFramework-SystemXmlLinq.csproj

src\PenImc\dll\PenImc.vcxproj
src\PenImc\tablib\TabLib.vcxproj

src\PresentationBuildTasks\PresentationBuildTasks.csproj

src\PresentationCore\PresentationCore.csproj
src\PresentationCore\ref\PresentationCore-ref.csproj

src\PresentationFramework\PresentationFramework.csproj
src\PresentationFramework\ref\PresentationFramework-ref.csproj

src\PresentationUI\PresentationUI.csproj
src\PresentationUI\ref\PresentationUI-ref.csproj

src\ReachFramework\ReachFramework.csproj
src\ReachFramework\ref\ReachFramework-ref.csproj

src\Shared\OSVersionHelper\OSVersionHelper.vcxproj

src\Shared\Tracing\wpf-etw.proj
src\Shared\Tracing\mcwpf\mcwpf.csproj

src\System.Printing\System.Printing.vcxproj
src\System.Printing\ref\System.Printing-ref.csproj

src\System.Windows.Controls.Ribbon\System.Windows.Controls.Ribbon.csproj
src\System.Windows.Controls.Ribbon\ref\System.Windows.Controls.Ribbon-ref.csproj
src\System.Windows.Controls.Ribbon\Themes\Generator\ThemeGenerator.proj

src\System.Windows.Input.Manipulations\System.Windows.Input.Manipulations.csproj
src\System.Windows.Input.Manipulations\ref\System.Windows.Input.Manipulations-ref.csproj

src\System.Windows.Presentation\System.Windows.Presentation.csproj
src\System.Windows.Presentation\ref\System.Windows.Presentation-ref.csproj

src\System.Xaml\System.Xaml.csproj
src\System.Xaml\ref\System.Xaml-ref.csproj

src\Themes\Generator\ThemeGenerator.nativeproj
src\Themes\PresentationFramework.Aero\PresentationFramework.Aero.csproj
src\Themes\PresentationFramework.Aero\ref\PresentationFramework.Aero-ref.csproj
src\Themes\PresentationFramework.Aero2\PresentationFramework.Aero2.csproj
src\Themes\PresentationFramework.Aero2\ref\PresentationFramework.Aero2-ref.csproj
src\Themes\PresentationFramework.AeroLite\PresentationFramework.AeroLite.csproj
src\Themes\PresentationFramework.AeroLite\ref\PresentationFramework.AeroLite-ref.csproj
src\Themes\PresentationFramework.Classic\PresentationFramework.Classic.csproj
src\Themes\PresentationFramework.Classic\ref\PresentationFramework.Classic-ref.csproj
src\Themes\PresentationFramework.Luna\PresentationFramework.Luna.csproj
src\Themes\PresentationFramework.Luna\ref\PresentationFramework.Luna-ref.csproj
src\Themes\PresentationFramework.Royale\PresentationFramework.Royale.csproj
src\Themes\PresentationFramework.Royale\ref\PresentationFramework.Royale-ref.csproj

src\UIAutomation\UIAutomationClient\UIAutomationClient.csproj
src\UIAutomation\UIAutomationClient\ref\UIAutomationClient-ref.csproj
src\UIAutomation\UIAutomationClientSideProviders\UIAutomationClientSideProviders.csproj
src\UIAutomation\UIAutomationClientSideProviders\ref\UIAutomationClientSideProviders-ref.csproj
src\UIAutomation\UIAutomationProvider\UIAutomationProvider.csproj
src\UIAutomation\UIAutomationProvider\ref\UIAutomationProvider-ref.csproj
src\UIAutomation\UIAutomationTypes\UIAutomationTypes.csproj
src\UIAutomation\UIAutomationTypes\ref\UIAutomationTypes-ref.csproj

src\WindowsBase\WindowsBase.csproj
src\WindowsBase\ref\WindowsBase-ref.csproj

src\WindowsFormsIntegration\WindowsFormsIntegration.csproj
src\WindowsFormsIntegration\ref\WindowsFormsIntegration-ref.csproj

src\WpfGfx\codegen\mcg\mcg.proj
src\WpfGfx\common\DynamicCall\DynamicCall.vcxproj
src\WpfGfx\common\effects\effects.vcxproj
src\WpfGfx\common\scanop\scanop.vcxproj
src\WpfGfx\common\shared\shared.vcxproj
src\WpfGfx\core\api\api.vcxproj
src\WpfGfx\core\av\av.vcxproj
src\WpfGfx\core\common\common.vcxproj
src\WpfGfx\core\control\dll\milctrl.vcxproj
src\WpfGfx\core\control\util\util.vcxproj
src\WpfGfx\core\dll\wpfgfx.vcxproj
src\WpfGfx\core\fxjit\Collector\Collector.vcxproj
src\WpfGfx\core\fxjit\Compiler\Compiler.vcxproj
src\WpfGfx\core\fxjit\PixelShader\PixelShader.vcxproj
src\WpfGfx\core\fxjit\Platform\Platform.vcxproj
src\WpfGfx\core\geometry\Geometry.vcxproj
src\WpfGfx\core\glyph\glyph.vcxproj
src\WpfGfx\core\hw\hw.vcxproj
src\WpfGfx\core\hw\shaders\ShaderGen\shadergen.nativeproj
src\WpfGfx\core\meta\meta.vcxproj
src\WpfGfx\core\resources\resources.vcxproj
src\WpfGfx\core\sw\swlib\sw.vcxproj
src\WpfGfx\core\targets\targets.vcxproj
src\WpfGfx\core\uce\uce.vcxproj
src\WpfGfx\DbgXHelper\DbgXHelper.vcxproj
src\WpfGfx\exts\exts.vcxproj
src\WpfGfx\include\GraphicsInclude.nativeproj
src\WpfGfx\shared\debug\DebugLib\DebugLib.vcxproj
src\WpfGfx\shared\util\ConUtil\ConUtil.nativeproj
src\WpfGfx\shared\util\DllUtil\DllUtil.vcxproj
src\WpfGfx\shared\util\ExeUtil\ExeUtil.nativeproj
src\WpfGfx\shared\util\UtilLib\UtilLib.vcxproj
src\WpfGfx\tools\csp\csp.csproj


                
```
