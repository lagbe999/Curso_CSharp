# Contributing

See [Contributing Guide](../Documentation/contributing.md) for information about:

* Which kind of PRs we accept/reject for .NET Core 3.0 release
* Coding style
* PR style preferences (squashing vs. merging, etc.)
* Developer guide for building and testing locally
