---
name: Feature / API request
about: Suggest an idea for this project
title: ''
labels: Untriaged
assignees: SamBent

---

Is this feature request related specifically to tooling in Visual Studio (e.g. XAML Designer, Code editing, etc...)? If yes, please file the request via the instructions here: https://docs.microsoft.com/visualstudio/ide/suggest-a-feature?view=vs-2019

<!-- Read https://github.com/dotnet/wpf/blob/master/Documentation/issue-guide.md -->
