using System;

namespace Company.ClassLibrary1
{
    public class Class1
    {
    }
}
