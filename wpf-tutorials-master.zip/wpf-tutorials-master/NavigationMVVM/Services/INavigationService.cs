﻿using NavigationMVVM.ViewModels;

namespace NavigationMVVM.Services
{
    public interface INavigationService
    {
        void Navigate();
    }
}