﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassCommands.Models
{
    public class OwnedItem
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
    }
}
