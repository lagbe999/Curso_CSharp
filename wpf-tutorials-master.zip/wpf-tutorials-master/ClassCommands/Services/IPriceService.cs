﻿namespace ClassCommands.Services
{
    public interface IPriceService
    {
        double GetPrice(string itemName);
    }
}