﻿using System.Windows.Controls;

namespace StateMVVM.Views
{
    public partial class PostHomeView : UserControl
    {
        public PostHomeView()
        {
            InitializeComponent();
        }
    }
}
