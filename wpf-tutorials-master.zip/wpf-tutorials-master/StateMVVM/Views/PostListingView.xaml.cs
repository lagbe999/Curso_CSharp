﻿using System.Windows.Controls;

namespace StateMVVM.Views
{
    public partial class PostListingView : UserControl
    {
        public PostListingView()
        {
            InitializeComponent();
        }
    }
}
