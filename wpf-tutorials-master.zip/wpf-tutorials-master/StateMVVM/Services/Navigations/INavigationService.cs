﻿using StateMVVM.ViewModels;

namespace StateMVVM.Services.Navigations
{
    public interface INavigationService
    {
        void Navigate();
    }
}