﻿namespace MVVMEssentials.Services
{
    public interface INavigationService
    {
        void Navigate();
    }
}