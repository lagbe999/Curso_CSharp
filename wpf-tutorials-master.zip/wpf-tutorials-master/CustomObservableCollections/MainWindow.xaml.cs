﻿using System.Windows;

namespace CustomObservableCollections
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
