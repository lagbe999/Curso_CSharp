## Rules to follow for this project:

* Every feature should be packed into the main executable, unless it's optional like FFmpeg, SharpDx and Gifski.
* To be accepted, any big feature or change should be discussed first with the maintainer of the project.
* PRs shoulkd be directed to the dev branch.
