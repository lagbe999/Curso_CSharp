﻿using System.Windows.Controls;

namespace ScreenToGif.UserControls
{
    public partial class MouseClicksPanel : UserControl
    {
        public MouseClicksPanel()
        {
            InitializeComponent();
        }
    }
}