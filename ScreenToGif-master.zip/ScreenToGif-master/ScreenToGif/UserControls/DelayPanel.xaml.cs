﻿using System.Windows.Controls;

namespace ScreenToGif.UserControls
{
    public partial class DelayPanel : UserControl
    {
        public DelayPanel()
        {
            InitializeComponent();
        }
    }
}