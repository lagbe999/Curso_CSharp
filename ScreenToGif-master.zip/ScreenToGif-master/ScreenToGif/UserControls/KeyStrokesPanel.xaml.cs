﻿using System.Windows.Controls;

namespace ScreenToGif.UserControls
{
    public partial class KeyStrokesPanel : UserControl
    {
        public KeyStrokesPanel()
        {
            InitializeComponent();
        }
    }
}