using System.Windows.Controls;

namespace ScreenToGif.UserControls
{
    public partial class ResizePanel : UserControl
    {
        public ResizePanel()
        {
            InitializeComponent();
        }
    }
}