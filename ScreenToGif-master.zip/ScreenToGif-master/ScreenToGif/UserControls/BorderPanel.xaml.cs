﻿using System.Windows.Controls;

namespace ScreenToGif.UserControls
{
    public partial class BorderPanel : UserControl
    {
        public BorderPanel()
        {
            InitializeComponent();
        }
    }
}