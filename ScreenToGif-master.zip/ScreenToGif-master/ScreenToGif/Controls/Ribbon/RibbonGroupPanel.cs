﻿using System.Windows;
using System.Windows.Controls;

namespace ScreenToGif.Controls.Ribbon
{
    public class RibbonGroupPanel : Panel
    {
        protected override Size ArrangeOverride(Size finalSize)
        {
            //?

            return base.ArrangeOverride(finalSize);
        }

        protected override Size MeasureOverride(Size availableSize)
        {

            return base.MeasureOverride(availableSize);
        }
    }
}