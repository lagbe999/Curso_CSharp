﻿## ScreenToGif Developer Documentation

Would you like to help build this developer documentation? 

### Sections

From an user perspective, the app is divided into two main parts, the recorders and the editor.