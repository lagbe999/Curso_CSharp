namespace ScreenToGif.Util
{
    public enum MouseButtonType
    {
        None,
        Left,
        Middle,
        Right
    }
}
