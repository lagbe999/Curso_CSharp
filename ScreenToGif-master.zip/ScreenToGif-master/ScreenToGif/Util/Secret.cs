﻿namespace ScreenToGif.Util
{
    public static class Secret
    {
        public static string ServerAddress { get; set; }

        public static string Email { get; set; }

        public static string Password { get; set; }

        public static int Port { get; set; }

        public static string Host { get; set; }


        public static string ImgurId { get; set; }

        public static string ImgurSecret { get; set; }

        public static string GfycatId { get; set; }

        public static string GfycatSecret { get; set; }

        public static string YandexId { get; set; }
    }
}