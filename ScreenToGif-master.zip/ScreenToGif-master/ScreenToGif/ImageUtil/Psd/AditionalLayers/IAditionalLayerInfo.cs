﻿namespace ScreenToGif.ImageUtil.Psd.AditionalLayers
{
    interface IAditionalLayerInfo : IPsdContent
    {
        string Key { get; }
    }
}