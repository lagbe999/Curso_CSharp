namespace ScreenToGif.ImageUtil.Gif.Decoder
{
    public enum GifBlockKind
    {
        Control,
        GraphicRendering,
        SpecialPurpose,
        Other
    }
}