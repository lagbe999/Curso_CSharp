namespace ScreenToGif.Interfaces
{
    interface IPersistent
    {
        void Persist();
    }
}