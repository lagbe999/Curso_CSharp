namespace MetaWebLogSite.XmlRpc
{
    public class MediaObjectInfo
    {
        public string url;
    }
}