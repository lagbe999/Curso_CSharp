namespace MetaWebLogSite.XmlRpc.Models
{
    public class MediaObject
    {
        public string name;
        public string type;
        public byte[] bits;
    }
}
