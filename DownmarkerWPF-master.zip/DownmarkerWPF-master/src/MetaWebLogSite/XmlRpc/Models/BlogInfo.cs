namespace MetaWebLogSite.XmlRpc.Models
{
    public class BlogInfo
    {
        public string blogid;
        public string url;
        public string blogName;
    }
}
