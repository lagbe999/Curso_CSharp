namespace MetaWebLogSite.XmlRpc
{
    public class UserInfo
    {
        public string userid;
        public string firstname;
        public string lastname;
        public string nickname;
        public string email;
        public string url;
    }
}