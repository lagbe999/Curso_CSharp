﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MarkPad.PluginApi")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("MarkPad.PluginApi")]
[assembly: AssemblyCompany("Code52")]
[assembly: AssemblyCopyright("Copyright © Code52 2013")]
[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("897765a6-82f6-41e4-9455-03b6cb18728f")]