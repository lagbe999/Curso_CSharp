namespace MarkPad.Document.Search
{
    public enum SearchType
    {
        Normal,
        Next,
        Prev,
        Replace,
        NoSelect // used when the visual lines refresh
    }
}
