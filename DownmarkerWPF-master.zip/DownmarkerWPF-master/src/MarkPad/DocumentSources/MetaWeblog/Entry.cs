using MarkPad.DocumentSources.MetaWeblog.Service;

namespace MarkPad.DocumentSources.MetaWeblog
{
    public class Entry
    {
        public string Key { get; set; }
        public Post Value { get; set; }
    }
}
