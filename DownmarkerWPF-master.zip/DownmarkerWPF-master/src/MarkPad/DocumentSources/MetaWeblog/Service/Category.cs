namespace MarkPad.DocumentSources.MetaWeblog.Service
{
    public struct Category
    {
        public string categoryId;
        public string categoryName;
    }
}
