using System;

namespace MarkPad.DocumentSources.MetaWeblog.Service
{
    [Serializable]
    public struct MediaObjectInfo
    {
        public string url;
    }
}
