
namespace MarkPad.DocumentSources.MetaWeblog.Service
{
    public partial class MetaWeblog
    {
        public MetaWeblog(string url)
        {
            Url = url;
        }
    }
}
