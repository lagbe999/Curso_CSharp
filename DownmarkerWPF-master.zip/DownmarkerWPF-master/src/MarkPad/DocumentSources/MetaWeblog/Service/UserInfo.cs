namespace MarkPad.DocumentSources.MetaWeblog.Service
{
    public struct UserInfo
    {
        public string userid;
        public string firstname;
        public string lastname;
        public string nickname;
        public string email;
        public string url;
    }
}
