namespace MarkPad.DocumentSources.GitHub
{
    public class GitBranch
    {
        public string name { get; set; }
    }
}