﻿namespace MarkPad.DocumentSources.WebSources
{
    public class SaveResult
    {
        public string Id { get; set; }
        public string NewDocumentContent { get; set; }
    }
}