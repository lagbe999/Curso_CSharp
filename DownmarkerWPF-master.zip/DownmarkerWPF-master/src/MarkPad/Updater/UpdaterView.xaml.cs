﻿namespace MarkPad.Updater
{
    public partial class UpdaterView
    {
        public UpdaterView()
        {
            InitializeComponent();
        }
    }
}
