namespace MarkPad.Updater
{
    public enum UpdateState
    {
        Unchecked,
        UpToDate,
        UpdatePending,
        Error,
        Downloading,
        RestartNeeded
    }
}