using System.Drawing;
using System.Windows.Media.Imaging;

namespace MarkPad.Helpers
{
    public class DataImage
    {
        public Bitmap Bitmap { get; set; }
        public BitmapSource BitmapSource { get; set; }
    }
}