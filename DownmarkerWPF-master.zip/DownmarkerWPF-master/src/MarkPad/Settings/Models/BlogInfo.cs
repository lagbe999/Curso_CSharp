using System;

namespace MarkPad.Settings.Models
{
    [Serializable]
    public struct BlogInfo
    {
        public string blogid;
        public string url;
        public string blogName;
    }
}
