namespace MarkPad.Settings.Models
{
    public enum IndentType
    {
        Spaces,
        Tabs
    }
}