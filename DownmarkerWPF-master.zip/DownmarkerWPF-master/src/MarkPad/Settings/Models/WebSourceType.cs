namespace MarkPad.Settings.Models
{
    public enum WebSourceType
    {
        MetaWebLog,
        GitHub
    }
}