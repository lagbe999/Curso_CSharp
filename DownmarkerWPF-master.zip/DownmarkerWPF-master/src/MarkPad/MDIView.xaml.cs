namespace MarkPad
{
    public partial class MdiView
    {
        public MdiView()
        {
            InitializeComponent();
        }
    }
}
