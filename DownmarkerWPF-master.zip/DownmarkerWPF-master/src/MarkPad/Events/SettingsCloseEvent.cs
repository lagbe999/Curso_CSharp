namespace MarkPad.Events
{
    public class SettingsCloseEvent
    {
    }
}