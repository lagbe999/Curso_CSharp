namespace MarkPad.Events
{
    public class SettingsChangedEvent
    {
    }
}
