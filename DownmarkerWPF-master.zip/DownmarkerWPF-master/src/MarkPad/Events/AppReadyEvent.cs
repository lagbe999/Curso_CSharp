namespace MarkPad.Events
{
    /// <summary>
    /// Event for components to subscribe to to execute code after the shell is visible
    /// </summary>
    public class AppReadyEvent
    {
        
    }
}
