namespace MarkPad.Infrastructure
{
    public interface IRaiseCanExecuteChanged
    {
        void RaiseCanExecuteChanged();
    }
}