namespace MarkPad.Infrastructure
{
    public interface IAsyncCommand : IAsyncCommand<object> { }
}