﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ExportToHtmlPlugin")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("ExportToHtmlPlugin")]
[assembly: AssemblyCompany("Code52")]
[assembly: AssemblyCopyright("Copyright © Code52 2013")]
[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0a02e5d2-ac4c-460b-8d26-7762e8e8d627")]