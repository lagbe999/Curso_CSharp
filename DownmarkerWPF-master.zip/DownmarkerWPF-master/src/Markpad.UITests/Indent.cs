﻿namespace MarkPad.UITests
{
    public class Indent
    {
        public static string Spaces
        {
            get { return "Spaces"; }
        }

        public static string Tabs
        {
            get { return "Tabs"; }
        }
    }
}